clear; clc; clf; close all;
ss=sprintf('u.m'); uu=load(ss); ss=sprintf('v.m'); vv=load(ss);
nx=32; ny=nx; yright=1; xright=1; h=xright/nx;
x=linspace(0.5*h,xright-0.5*h,nx); y=linspace(0.5*h,yright-0.5*h,ny);
[xx,yy]=meshgrid(x,y); N=size(uu,1)/nx; s=0.1;
for kk=1:11
    figure;
    u=uu(1+(kk-1)*nx:kk*nx,:); v=vv(1+(kk-1)*nx:kk*nx,:);
    us=u'; vs=v';
    for i=1:nx
        for j=1:ny
            if rand() < 0.2
                us(i,j)=0;
                vs(i,j)=0;
            end
        end
    end
    quiver(xx(1:2:end,:),yy(1:2:end,:),s*us(1:2:end,:),s*vs(1:2:end,:),0,'k')
    axis image
    set(gca,'xtick',[]); set(gca,'ytick',[]);
end