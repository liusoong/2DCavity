clc
clear;
clf;
close all

ss=sprintf('p.m');  
para=load(ss);
ny=size(para,2);
nx=ny;
xright=1.0;
yright=1.0;
h=xright/nx;
x=linspace(0.5*h,xright-0.5*h,nx);
y=linspace(0.5*h,yright-0.5*h,ny);
[xx,yy]=meshgrid(x,y);

nn=size(para,1)/nx;
for i=1:nn
    
aa=para(1+(i-1)*nx:i*nx,:);

mesh(xx,yy,aa')
pause(0.5)
end






